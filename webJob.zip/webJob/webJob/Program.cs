﻿using System;
using System.Data.Entity;
using Microsoft.Extensions.Hosting;

using Microsoft.Extensions.Logging;
using Microsoft.Azure.WebJobs;
using Microsoft.WindowsAzure.Storage.Table;

namespace webJob
{
    class Program
    {
        static void Main(string[] args)
        {
            

            var builder = new HostBuilder();
            builder.ConfigureWebJobs(b =>
            {
                b.AddAzureStorageCoreServices();
            });
            builder.ConfigureLogging((context, b) =>
            {
                b.AddConsole();
            });
            var host = builder.Build();
            using (host)
            {
                host.Run();
            }


        }


        public class WebJob
        {
            public static void ProcessQueue(
                [QueueTrigger("azure-coder-queue")]QueueModel message,
                [Table("AzureCoderTable")]out DataModel model,
                System.IO.TextWriter log)
            {
                log.WriteLine($"Found message {message.LastName}, {message.FirstName}");
                model = new DataModel
                {
                    PartitionKey = message.LastName,
                    RowKey = message.FirstName
                };
            }
        }
        public class QueueModel
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
        }
        public class DataModel : TableEntity
        {
            internal string PartitionKey;
            internal string RowKey;
        }
    }


}

